
# to plot
from matplotlib import pyplot as plt

import numpy as np
from dataclasses import dataclass
# to do sin and cos
import math

@dataclass
class node:
  #position in the x
  x: int
  #position in the y
  y: int
  
@dataclass
class Member:
  #node 1 connected to member 
  node1: node
  #node 2 connected to member 
  node2: node
  # angle measure
  angle: float

@dataclass
class reaction:
  #node at which the pin/roller is loacated
  node: node
  #if the pin/roller allows movement in the x direction
  x: bool
  #if the pin/roller allows movement in the y direction
  y: bool

@dataclass
class forces:
  #magnitude of the force in the x
  x: float
  #magnitude of the force in the y
  y: float
  #angle at which the force is applied 
  angle: float
  #node at wich the force is applied 
  node: node

#number of nodes within truss
nodes = int(input("Input number of nodes in truss: "))

while(nodes < 2):
  nodes = int(input("Cannot have less than 2 nodes in a truss: "))
  
nodelist = [0 for row in range(nodes)]

for i in range(nodes):
  tempx = int(input("Input x coordinate of node " + (str)(i + 1) + ": "))
  tempy = int(input("Input y coordinate of node " + (str)(i + 1) + ": "))
  nodelist[i] = node(tempx, tempy)

members = int(input("Input number of members in the truss: "))

connections = [0 for row in range(members)]

for i in range(members):
  node1 = int(input("Input first node for member " + (str)(i + 1) + ": "))
  
  if (node1 <= 0 or node1 > nodes):
    node1 = int(input("Input first node for member " + (str)(i + 1) + ": "))
    
  node2 = int(input("Input second node for member " + (str)(i + 1) + ": "))
  
  if (node2 <= 0 or node2 > nodes or node1 == node2):
    node2 = int(input("Input second node for member " + (str)(i + 1) + ": "))
  
  if ((nodelist[node1-1].x-nodelist[node2-1].x) == 0):
    angle = math.radians(90)
  else:
    angle = float(math.atan((nodelist[node1-1].y-nodelist[node2-1].y)/(nodelist[node1-1].x-nodelist[node2-1].x)))
    
  connections[i] = Member(nodelist[node1-1], nodelist[node2-1], angle)

#Start of reaction analysis
react = int(input("Input number of supports in truss: "))

while(react < 2):
  react = int(input("Cannot have less than 1 supports in a truss: "))

reactionlist = [0 for row in range(react)]
#nodeReact = [0 for row in range(react)]

for i in range(react):
  tempLoc = int(input("Input the node associated with the support type: "))
  
  if (tempLoc <= 0 or tempLoc > nodes):
    tempLoc = int(input("Input the node associated with the support type: "))

  sup = int(input("Input type of support. 1 for Pin and 0 for Roller: "))


  #nodeReact[i] = tempLoc 
  
  if (sup == 1):
    reactionlist[i] = reaction(nodelist[tempLoc - 1],1,1)
  elif (sup == 0):
    reactionlist[i] = reaction(nodelist[tempLoc - 1],0,1)


force = int(input("Please enter number of external forces on truss: "))

forceslist = [0 for row in range(force)]

for i in range(force):
  mag= float(input("Please input resultant magnitude of force: "))
  
  tempLoc = int(input("Input node at which the force is applied: "))
  if (tempLoc <= 0 or tempLoc > nodes):
    tempLoc = int(input("Input node at which the force is applied: "))
    
  angle= float(input("Input force angle from horizontal. Must be total angle measure: "))
  tempx = mag*np.cos(np.deg2rad(angle))
  tempy = mag*np.sin(np.deg2rad(angle))
  forceslist[i] = forces(tempx,tempy,angle,nodelist[tempLoc - 1])

moments = np.zeros(shape = (nodes,nodes*2)) 
fd = np.zeros(shape = (nodes, 1))


for i in range(nodes):
  for j in range(nodes):
    test = bool(0)
    count = int(0)
    while (test != 1 and count < nodes):
      for k in range(react):
        if (nodelist[j] == reactionlist[k].node):
          p = k
          test = 1
        else:
          count = count+1
    if (test == 1):
      moments[i][2*j] = (reactionlist[p].node.y - nodelist[i].y)*reactionlist[p].x
      moments[i][2*j+1] = (reactionlist[p].node.x - nodelist[i].x)*reactionlist[p].y
    else:
      moments[i][2*j] = 0
      moments[i][2*j+1] = 0

print(moments)
for i in range(nodes):
  for j in range(force):
    fd[i] = -(fd[i] + ((forceslist[j].x)*(forceslist[j].node.y-nodelist[i].y))+((forceslist[j].y)*(forceslist[j].node.x-nodelist[i].x)))
print(fd)
solution = np.dot(np.linalg.pinv(moments),fd)
print(solution)
## End WorkSpace

#Start of internal force analysis
solvMat = np.zeros(shape = (nodes*2, members))

for i in range(nodes):
  for j in range(members):
    dist = (math.sqrt(((connections[j].node2.x-connections[j].node1.x)**2)+(connections[j].node2.y-connections[j].node1.y)**2))
    if (connections[j].node1 == nodelist[i]): 
      solvMat[i*2][j] = (connections[j].node2.x-connections[j].node1.x)/dist
      solvMat[i*2+1][j] = (connections[j].node2.y-connections[j].node1.y)/dist
    elif (connections[j].node2 == nodelist[i]):
      solvMat[i*2][j] = (connections[j].node1.x-connections[j].node2.x)/dist
      solvMat[i*2+1][j] = (connections[j].node1.y-connections[j].node2.y)/dist
    else:
      solvMat[i*2][j] = 0
      solvMat[i*2+1][j] = 0

print(solvMat)


for i in range(nodes):
  for j in range(force):
    if(forceslist[j].node == nodelist[i]):
      solution[i*2] = solution[i*2] + forceslist[j].x
      solution[i*2+1] = solution[i*2+1] + forceslist[j].y
print(solution)

truss = np.dot(np.linalg.pinv(solvMat),solution)
print(truss)
#display  
      # set up display window
plt.rcParams["figure.figsize"] = [7.50, 3.50]
plt.rcParams["figure.autolayout"] = True

for i in range(nodes):
  # plot the nodes as points
  plt.scatter(nodelist[i].x,nodelist[i].y)

# find the max and min vales of x and y out of all the nodes
maxx = nodelist[0].x
minx = nodelist[0].x
maxy = nodelist[0].y
miny = nodelist[0].y

for i in np.arange(1,nodes,1):
  if(nodelist[i].x < minx):
    minx = nodelist[i].x
  if(nodelist[i].x > maxx):
    maxx = nodelist[i].x
  if(nodelist[i].y < miny):
    miny = nodelist[i].y
  if(nodelist[i].y > maxy):
    maxy = nodelist[i].y
# set limits to 2 outside the min and maxes   
plt.xlim(minx -2, maxx+2)
plt.ylim(miny-2, maxy+2)

# plotting the members/ plotting the lines between the nodes
for i in np.arange(0,members,1):
  # array of all the x components of each node in each member
  xval = [connections[i].node1.x,connections[i].node2.x]
  print(xval)
  #array of all the y components on each node in each member
  yval = [connections[i].node1.y,connections[i].node2.y]

  if (truss[i] >=0):
    plt.plot(xval,yval, 'r', linestyle = "-")
  elif (truss[i] < 0):
    plt.plot(xval, yval, 'bo', linestyle = "-")

# plotting the arrow
for i in np.arange(0,force,1):
  # change the angle into radians
  ang = math.radians (forceslist[i].angle) 
  # plot the arrow 
  #plt.arrow(starting x, starting y, length of errow in x, len of arrow in y)
  plt.arrow(forceslist[i].node.x, forceslist[i].node.y, math.cos (ang) ,math.sin(ang),head_width = 0.2,width = 0.05)

# plot the reaction forces
for i in np.arange(0,react,1): 
  #if reaction is a pin/ if it is constrained in the x direction 
  if reactionlist[i].x == 1:
    # plot a pin/triangle
    # plt.plot(x loaction, y location, shape, size, border color, inside color)
    # note that the y position is moved down 0.5 so you can see the actual node
    plt.plot(reactionlist[i].node.x, reactionlist[i].node.y-0.5, marker="^", markersize=20, markeredgecolor="red", markerfacecolor="green")
    # plot a roller/ circle
  else:
    plt.plot(reactionlist[i].node.x, reactionlist[i].node.y-0.5, marker="o", markersize=20, markeredgecolor="red", markerfacecolor="green")

#display all the plotting
plt.show()